/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examenpractico;

/**
 *
 * @author Aulas Heredia
 */
public class ExamenPractico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        string nombreAgente;
        int id;
        string codigo; 
        string sucursal; 
        boolean vehiculo;
        
        System.out.println("Indique el nombre de Usuario: ");
        System.out.println("Indique su numero de ID: ");
        System.out.println("Indique su Codigo: ");
        System.out.println("Indiqure el lugar de su sucursal: ");
        System.out.println("Cuenta con vehiculo?: ");
        
        datosCliente dataUno = new dataUno(Julio Sanchez, 11202000,  2351, 20000, 0 , 0, 6 );
        
        System.out.println("nombreCliente: " + datUno.getstring());
        System.out.println("id: "+datoUno.getId());
        System.out.println("numFactura: " +datoUno.getdouble());
        System.out.println("montoFactura: "+datoUno.getDouble());
        System.out.println("productsElectricos: "+datoUno.getBoolean());
        System.out.println("productsAutomotrices: "+datoUno.getBoolean());
        System.out.println("productsConstruccion: "+datoUno.getBoolean());
        
        datoUno.datosCliente("Julio Sanchez");       
        
        
        
        
        
        
    }
    
}
